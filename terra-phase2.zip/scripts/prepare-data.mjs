// Generates src/data/countries.ts and src/data/worldBorders.json for Terra.
//
// Sources (both open data, no API keys, no network calls at runtime):
//  - world-countries (mledoze)  — country attributes. License: ODbL.
//  - world-atlas + topojson-client — simplified (110m) border geometry, derived
//    from Natural Earth (public domain).
//
// Re-run with: npm install world-countries world-atlas topojson-client --no-save
//              node prepare-data.mjs
import countries from "world-countries";
import topology from "world-atlas/countries-110m.json" with { type: "json" };
import * as topojson from "topojson-client";
import { writeFileSync } from "node:fs";

// ---- Hand-curated highlights for a first wave of featured countries -------
// (accent color pulled from each flag's most distinctive hue; fun facts are
// original wording, not sourced from any single text.)
const FEATURED = {
  USA: { accentColor: "#3C3B6E", funFact: "The United States has no official language at the federal level — English is dominant by custom, not law." },
  CAN: { accentColor: "#FF0000", funFact: "Canada has the longest coastline of any country on Earth, touching the Atlantic, Pacific, and Arctic oceans." },
  MEX: { accentColor: "#006847", funFact: "Chocolate, corn, tomatoes, and vanilla were all first domesticated in Mexico by ancient Mesoamerican civilizations." },
  BRA: { accentColor: "#009739", funFact: "Brazil is the only country in the Americas where Portuguese is the official language, a legacy of 16th-century colonization." },
  CHL: { accentColor: "#D52B1E", funFact: "Chile stretches over 4,300 km north to south but is never more than about 350 km wide, squeezed between the Andes and the Pacific." },
  GBR: { accentColor: "#00247D", funFact: "The United Kingdom is a union of four countries — England, Scotland, Wales, and Northern Ireland." },
  FRA: { accentColor: "#0055A4", funFact: "France has more time zones than any other country — 12 in total, thanks to its overseas territories." },
  DEU: { accentColor: "#FFCE00", funFact: "\"Deutschland\" comes from an old Germanic word that simply meant \"the people.\"" },
  ITA: { accentColor: "#009246", funFact: "Italy has 58 UNESCO World Heritage Sites, more than any other country." },
  ESP: { accentColor: "#AA151B", funFact: "Spanish is native to Spain, but more native speakers now live in Mexico than in Spain itself." },
  ISL: { accentColor: "#02529C", funFact: "Iceland keeps no standing army, and its capital Reykjavík is heated almost entirely by geothermal energy." },
  RUS: { accentColor: "#0039A6", funFact: "Russia spans 11 time zones — more than any other country on Earth." },
  EGY: { accentColor: "#CE1126", funFact: "Egypt is transcontinental: the Sinai Peninsula lies in Asia while the rest of the country sits in Africa." },
  NGA: { accentColor: "#008751", funFact: "Nigeria is Africa's most populous country, and Lagos is projected to become one of the largest cities on Earth." },
  KEN: { accentColor: "#006600", funFact: "Kenya's Great Rift Valley is slowly tearing East Africa apart — in a few million years it will split into a new landmass." },
  ZAF: { accentColor: "#007A4D", funFact: "South Africa has three capital cities — Pretoria, Cape Town, and Bloemfontein — each hosting a different branch of government." },
  COD: { accentColor: "#007FFF", funFact: "The Democratic Republic of the Congo and the Republic of the Congo face each other across the Congo River — the only capitals in the world to do so." },
  COG: { accentColor: "#009543", funFact: "Brazzaville and Kinshasa, the two Congos' capitals, are the closest pair of capital cities in the world." },
  JPN: { accentColor: "#BC002D", funFact: "Japan's own name for itself, Nippon, translates to \"origin of the sun\" — the source of \"Land of the Rising Sun.\"" },
  CHN: { accentColor: "#DE2910", funFact: "China shares land borders with 14 countries, tied with Russia for the most of any nation." },
  IND: { accentColor: "#FF9933", funFact: "India recognizes 22 official languages, and its banknotes print the currency value in 15 different scripts." },
  NPL: { accentColor: "#DC143C", funFact: "Nepal's flag is the only national flag in the world that isn't rectangular — two stacked triangular pennants for the Himalayas." },
  THA: { accentColor: "#A51931", funFact: "Thailand is the only country in Southeast Asia that was never colonized by a European power." },
  AUS: { accentColor: "#00008B", funFact: "Australia is the only country that is also an entire continent." },
  NZL: { accentColor: "#00247D", funFact: "New Zealand is one of the last major landmasses on Earth settled by humans, first reached by Polynesian voyagers around 1300 CE." },
  VAT: { accentColor: "#FFE000", funFact: "Vatican City is the smallest internationally recognized country in the world — smaller than most golf courses." },
};

// ---- Border geometry: ccn3 (numeric) -> cca3, from world-countries --------
const ccn3ToCca3 = new Map(countries.map((c) => [c.ccn3, c.cca3]));

const geo = topojson.feature(topology, topology.objects.countries);

const round = (n) => Math.round(n * 100) / 100;

const worldBorders = geo.features.map((f) => {
  const cca3 = ccn3ToCca3.get(f.id) ?? null;
  const polys =
    f.geometry?.type === "Polygon"
      ? [f.geometry.coordinates]
      : f.geometry?.type === "MultiPolygon"
      ? f.geometry.coordinates
      : [];
  const outerRings = polys
    .map((poly) => poly[0]) // outer ring only, ignore holes (lakes) for now
    .filter(Boolean)
    .map((ring) => ring.map(([lon, lat]) => [round(lon), round(lat)]));

  return {
    id: cca3 ?? `n${f.id}`,
    matched: Boolean(cca3),
    outerRings,
  };
});

const borderCoverage = new Set(worldBorders.filter((b) => b.matched).map((b) => b.id));

// ---- Country attributes ----------------------------------------------------
function callingCode(idd) {
  if (!idd?.root) return undefined;
  if (!idd.suffixes || idd.suffixes.length === 0) return idd.root;
  if (idd.suffixes.length > 5) return idd.root; // shared-code region (e.g. NANP); suffixes are area codes
  return idd.root + idd.suffixes[0];
}

const terraCountries = countries
  .filter((c) => c.independent || c.unMember || c.cca3 === "VAT") // sovereign states + Vatican
  .map((c) => {
    const featured = FEATURED[c.cca3];
    return {
      id: c.cca3,
      cca2: c.cca2,
      ccn3: c.ccn3,
      name: { common: c.name.common, official: c.name.official },
      flagEmoji: c.flag,
      region: c.region,
      subregion: c.subregion || undefined,
      capital: c.capital && c.capital.length ? c.capital : undefined,
      latlng: [c.latlng[0], c.latlng[1]],
      areaKm2: c.area || undefined,
      population: c.population || undefined,
      languages: c.languages ? Object.values(c.languages) : undefined,
      currencies: c.currencies
        ? Object.entries(c.currencies).map(([code, v]) => ({ code, name: v.name, symbol: v.symbol }))
        : undefined,
      callingCode: callingCode(c.idd),
      tld: c.tld && c.tld.length ? c.tld : undefined,
      landlocked: c.landlocked ?? undefined,
      borders: c.borders && c.borders.length ? c.borders : undefined,
      hasBorderGeometry: borderCoverage.has(c.cca3),
      accentColor: featured?.accentColor,
      funFact: featured?.funFact,
    };
  })
  .sort((a, b) => a.name.common.localeCompare(b.name.common));

// ---- Write output -----------------------------------------------------------
const tsOut =
  `// AUTO-GENERATED by data-prep/prepare-data.mjs — do not hand-edit.\n` +
  `// Source: world-countries (ODbL) — https://github.com/mledoze/countries\n` +
  `import type { Country } from "../types/country";\n\n` +
  `export const COUNTRIES: Country[] = ${JSON.stringify(terraCountries, null, 2)} satisfies Country[];\n`;

writeFileSync(new URL("./out-countries.ts", import.meta.url), tsOut);
writeFileSync(
  new URL("./out-worldBorders.json", import.meta.url),
  JSON.stringify(worldBorders)
);

console.log(`Countries: ${terraCountries.length}`);
console.log(`Border features: ${worldBorders.length} (matched: ${borderCoverage.size})`);
console.log(`Featured (fun fact) countries: ${Object.keys(FEATURED).length}`);
const unmatchedFeatured = Object.keys(FEATURED).filter((id) => !borderCoverage.has(id));
if (unmatchedFeatured.length) console.log("Featured w/o polygon geometry:", unmatchedFeatured);
