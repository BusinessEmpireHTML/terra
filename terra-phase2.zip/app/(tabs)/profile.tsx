import React from "react";
import { PlaceholderScreen } from "../../src/screens/PlaceholderScreen";

export default function ProfileTab() {
  return (
    <PlaceholderScreen
      icon="person-circle-outline"
      title="Stats, streaks, and achievements"
      phase="Phase 4"
      note="Mastery levels, badges, and your exploration history will live here."
    />
  );
}
