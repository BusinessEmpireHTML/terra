import React from "react";
import { PlaceholderScreen } from "../../src/screens/PlaceholderScreen";

export default function LearnTab() {
  return (
    <PlaceholderScreen
      icon="school-outline"
      title="Flags, capitals, and quizzes"
      phase="Phase 3"
      note="Spaced-repetition learning modes and mastery tracking land here once the country content is filled in."
    />
  );
}
