import type { CountryContent } from "../types/country";

/**
 * Phase 2, wave 1: History / Culture / Nature / Food / Landmarks for a
 * curated set of countries spanning every continent. Original wording
 * throughout — nothing copied from any single source. Every field is
 * independent, so a country can have three sections filled in and two
 * still missing; CountryDetailScreen handles that gracefully.
 *
 * Add more countries here over time — this file is hand-maintained, unlike
 * src/data/countries.ts, and re-running scripts/prepare-data.mjs never
 * touches it.
 */
export const COUNTRY_CONTENT: Record<string, CountryContent> = {
  USA: {
    history: [
      { year: "1776", label: "Declaration of Independence signed, breaking from British rule" },
      { year: "1787", label: "US Constitution drafted in Philadelphia" },
      { year: "1861–65", label: "Civil War fought over slavery and the union" },
      { year: "1920", label: "19th Amendment grants women the right to vote" },
      { year: "1969", label: "Apollo 11 lands the first humans on the Moon" },
    ],
    culture:
      "American culture is a patchwork shaped by waves of immigration, regional identity, and a strong tradition of individualism. From jazz and hip-hop to Hollywood film, much of the 20th century's global pop culture originated here, blending influences from Africa, Europe, and Latin America.",
    nature:
      "The country spans nearly every biome on Earth — Arctic tundra in Alaska, desert in the Southwest, temperate rainforest in the Pacific Northwest, and the Everglades' subtropical wetlands in Florida. Yellowstone, established in 1872, was the world's first national park.",
    food: [
      { name: "Barbecue", note: "Slow-smoked meat traditions vary by region — Texas brisket, Carolina pulled pork, Kansas City ribs." },
      { name: "Apple pie", note: "A dessert so tied to national identity it became cultural shorthand for Americana." },
      { name: "Tex-Mex", note: "A border-region fusion of Mexican and American Southern cooking." },
    ],
    landmarks: [
      { name: "Statue of Liberty", note: "A gift from France in 1886, it was the first sight of America for millions of arriving immigrants." },
      { name: "Grand Canyon", note: "Carved by the Colorado River over roughly 5–6 million years, it stretches nearly 450 km." },
      { name: "Golden Gate Bridge", note: "Completed in 1937; its International Orange color was chosen to stand out against San Francisco's fog." },
    ],
  },

  BRA: {
    history: [
      { year: "1500", label: "Portuguese explorers arrive, beginning colonization" },
      { year: "1822", label: "Brazil declares independence from Portugal" },
      { year: "1888", label: "Slavery abolished — the last country in the Americas to do so" },
      { year: "1960", label: "Capital moved from Rio de Janeiro to the newly built city of Brasília" },
    ],
    culture:
      "Brazil's culture blends Indigenous, African, and Portuguese roots into something distinct — samba and Carnival, capoeira, and a deep national passion for football. Rio's Carnival draws millions of visitors each year and ranks among the largest street festivals on Earth.",
    nature:
      "More than half of Brazil is covered by the Amazon rainforest, home to an estimated 10% of all known species on the planet. The country also holds the Pantanal, the world's largest tropical wetland.",
    food: [
      { name: "Feijoada", note: "A hearty black bean and pork stew, considered the national dish." },
      { name: "Pão de queijo", note: "Chewy cheese bread made with tapioca flour, a breakfast staple." },
      { name: "Açaí bowl", note: "A frozen Amazonian berry, blended and topped with granola and fruit." },
    ],
    landmarks: [
      { name: "Christ the Redeemer", note: "Completed in 1931 atop Corcovado mountain, overlooking Rio de Janeiro." },
      { name: "Iguazu Falls", note: "A system of nearly 275 waterfalls shared with Argentina, wider than Niagara." },
      { name: "Amazon River", note: "The largest river by discharge volume on Earth — more water than the next several largest combined." },
    ],
  },

  CHL: {
    history: [
      { year: "1541", label: "Santiago founded by Spanish conquistador Pedro de Valdivia" },
      { year: "1818", label: "Chile declares independence from Spain" },
      { year: "1973–90", label: "Military dictatorship under Augusto Pinochet" },
      { year: "1990", label: "Return to democratic government" },
    ],
    culture:
      "Chilean culture is shaped by extreme geography — hemmed in by the Andes, the Pacific, and the Atacama Desert, it developed a distinct identity. Poetry runs deep here: Chile has produced two Nobel laureates in literature, Gabriela Mistral and Pablo Neruda.",
    nature:
      "Chile's length gives it an extraordinary range of landscapes: the driest non-polar desert on Earth in the north, temperate rainforest and volcanoes in the center-south, and Patagonian glaciers near its tip.",
    food: [
      { name: "Empanadas", note: "Baked pastries filled with beef, onion, olives, and egg." },
      { name: "Curanto", note: "A traditional dish from Chiloé, cooked in a pit with hot stones." },
      { name: "Pastel de choclo", note: "A corn and beef casserole, sweet and savory together." },
    ],
    landmarks: [
      { name: "Easter Island (Rapa Nui)", note: "Home to nearly 900 moai statues carved by the Rapa Nui people, over 3,700 km from the mainland." },
      { name: "Atacama Desert", note: "So dry that some stations have never recorded rainfall; its clear skies make it a hub for astronomy." },
      { name: "Torres del Paine", note: "Granite towers and glacial lakes in Chilean Patagonia." },
    ],
  },

  FRA: {
    history: [
      { year: "1789", label: "French Revolution begins, ending centuries of absolute monarchy" },
      { year: "1804", label: "Napoleon Bonaparte crowned Emperor" },
      { year: "1889", label: "Eiffel Tower completed for the World's Fair" },
      { year: "1944", label: "Liberation of Paris from occupation" },
    ],
    culture:
      "France's cultural exports — fashion, cinema, philosophy, and cuisine — have shaped global taste for centuries. Paris remains a symbolic capital of art and ideas, and French gastronomy was one of the first culinary traditions added to UNESCO's Intangible Cultural Heritage list.",
    nature:
      "From the Alps in the east to the Atlantic coastline in the west, France holds remarkable geographic range within a relatively compact area, including Mont Blanc, Western Europe's highest peak.",
    food: [
      { name: "Croissant", note: "A laminated butter pastry that became a breakfast icon worldwide." },
      { name: "Coq au vin", note: "Chicken braised slowly in red wine, a classic of home cooking." },
      { name: "Cheese", note: "France produces over 1,000 varieties, from Camembert to Roquefort." },
    ],
    landmarks: [
      { name: "Eiffel Tower", note: "Built as a temporary exhibit in 1889, it was nearly torn down before becoming a permanent icon." },
      { name: "Palace of Versailles", note: "The opulent former royal residence, its Hall of Mirrors a symbol of absolute monarchy." },
      { name: "Mont Saint-Michel", note: "A tidal island abbey that appears to float when the tide comes in." },
    ],
  },

  ITA: {
    history: [
      { year: "753 BCE", label: "Traditional founding date of Rome" },
      { year: "27 BCE", label: "Roman Empire begins under Augustus" },
      { year: "1300s–1600s", label: "The Renaissance transforms art, science, and thought" },
      { year: "1861", label: "Italy unifies into a single kingdom" },
    ],
    culture:
      "Italy's regions each carry distinct dialects, cuisines, and traditions — unification came late, in 1861, and local identity remains strong. The country has more UNESCO World Heritage Sites than any other nation.",
    nature:
      "The Apennine mountains run the length of the peninsula, and active volcanoes — Vesuvius, Etna, Stromboli — are a reminder the landscape is still being shaped.",
    food: [
      { name: "Pizza", note: "Born in Naples; the Margherita was reputedly created in 1889 to honor Italy's queen." },
      { name: "Pasta", note: "Hundreds of shapes exist, many tied to specific regions and sauces." },
      { name: "Gelato", note: "Denser and less airy than ice cream, churned slower for a silkier texture." },
    ],
    landmarks: [
      { name: "Colosseum", note: "Completed in 80 CE, it could hold an estimated 50,000–80,000 spectators." },
      { name: "Venice canals", note: "A city built across more than 100 small islands, linked by canals and bridges." },
      { name: "Leaning Tower of Pisa", note: "Its tilt began during construction in the 12th century, due to soft ground." },
    ],
  },

  EGY: {
    history: [
      { year: "3100 BCE", label: "Upper and Lower Egypt unified under the first pharaoh" },
      { year: "2560 BCE", label: "Great Pyramid of Giza completed" },
      { year: "30 BCE", label: "Egypt becomes a Roman province after Cleopatra's death" },
      { year: "1922", label: "Egypt gains independence from British rule" },
      { year: "1971", label: "Aswan High Dam completed, reshaping the Nile's flooding" },
    ],
    culture:
      "Egyptian identity blends Pharaonic, Arab, and Islamic heritage. Cairo is one of the largest cities in the Arab world and a historic center of Islamic scholarship, home to Al-Azhar, one of the oldest universities on Earth.",
    nature:
      "More than 90% of Egypt is desert; nearly all of its population lives along the narrow, fertile Nile River valley and delta.",
    food: [
      { name: "Koshari", note: "A layered dish of rice, lentils, pasta, and spiced tomato sauce — the national dish." },
      { name: "Ful medames", note: "Slow-cooked fava beans, a breakfast staple for centuries." },
      { name: "Molokhia", note: "A leafy green stew, often served with rice or bread." },
    ],
    landmarks: [
      { name: "Great Pyramid of Giza", note: "The last surviving wonder of the ancient world; the tallest structure on Earth for nearly 3,800 years." },
      { name: "Karnak Temple", note: "A vast temple complex built and expanded over roughly 2,000 years." },
      { name: "Abu Simbel", note: "Massive rock temples relocated in the 1960s to save them from flooding by the Aswan Dam." },
    ],
  },

  KEN: {
    history: [
      { year: "1895", label: "British East Africa Protectorate established" },
      { year: "1952–60", label: "Mau Mau uprising against colonial rule" },
      { year: "1963", label: "Kenya gains independence" },
      { year: "1964", label: "Jomo Kenyatta becomes the country's first president" },
    ],
    culture:
      "Kenya is home to more than 40 ethnic groups, each with distinct languages and traditions, unified by Swahili and English as official languages. Long-distance running is a source of enormous national pride — Kenyan athletes have dominated marathon and middle-distance events for decades.",
    nature:
      "The Great Rift Valley cuts through the country, and the annual wildebeest migration across the Maasai Mara is one of the largest wildlife movements on Earth.",
    food: [
      { name: "Ugali", note: "A firm maize porridge, the staple starch of most meals." },
      { name: "Nyama choma", note: "Grilled meat, usually goat or beef, often a centerpiece of gatherings." },
      { name: "Sukuma wiki", note: "Sautéed collard greens, whose name means 'to stretch the week.'" },
    ],
    landmarks: [
      { name: "Maasai Mara", note: "A wildlife reserve famous for the Great Migration of wildebeest and zebra." },
      { name: "Mount Kenya", note: "Africa's second-highest peak, and the country's namesake." },
      { name: "Lake Nakuru", note: "Once famous for vast flocks of flamingos drawn to its alkaline waters." },
    ],
  },

  ZAF: {
    history: [
      { year: "1652", label: "Dutch establish a supply station at the Cape" },
      { year: "1948", label: "Apartheid formally instituted" },
      { year: "1990", label: "Nelson Mandela released after 27 years in prison" },
      { year: "1994", label: "First multiracial democratic elections; Mandela becomes president" },
    ],
    culture:
      "South Africa is often called the 'Rainbow Nation' for its diversity — 12 official languages are recognized, more than any other country. Music played a major role in the anti-apartheid movement and remains central to national identity.",
    nature:
      "The country spans desert, savanna, and Mediterranean-climate fynbos found almost nowhere else on Earth, concentrated in the Cape Floristic Region.",
    food: [
      { name: "Bobotie", note: "Spiced minced meat baked with an egg topping, of Cape Malay origin." },
      { name: "Braai", note: "A social barbecue tradition central to gatherings across the country." },
      { name: "Biltong", note: "Air-dried, cured meat — a popular snack descended from settler preservation methods." },
    ],
    landmarks: [
      { name: "Table Mountain", note: "A flat-topped mountain over Cape Town, part of one of the world's richest plant kingdoms." },
      { name: "Kruger National Park", note: "One of Africa's largest game reserves, home to the 'Big Five.'" },
      { name: "Robben Island", note: "Where Nelson Mandela was imprisoned for 18 of his 27 years in custody." },
    ],
  },

  JPN: {
    history: [
      { year: "794", label: "Heian period begins, a golden age of court culture" },
      { year: "1603", label: "Tokugawa shogunate begins two centuries of isolation" },
      { year: "1868", label: "Meiji Restoration ends the shogunate, rapidly modernizes Japan" },
      { year: "1945", label: "World War II ends after the atomic bombings of Hiroshima and Nagasaki" },
      { year: "1964", label: "Tokyo hosts the first Olympics held in Asia" },
    ],
    culture:
      "Japanese culture balances deep tradition with rapid modernity — tea ceremony and centuries-old shrines coexist with a global pop-culture export machine in anime, manga, and video games.",
    nature:
      "Japan sits on the Pacific Ring of Fire, giving it more than 100 active volcanoes and frequent earthquakes, alongside dramatic seasonal change — cherry blossoms in spring, fiery maple leaves in autumn.",
    food: [
      { name: "Sushi", note: "Vinegared rice paired with seafood, evolved from a fermentation preservation method centuries ago." },
      { name: "Ramen", note: "Wheat noodles in broth, with countless regional styles." },
      { name: "Tempura", note: "Lightly battered, deep-fried seafood and vegetables." },
    ],
    landmarks: [
      { name: "Mount Fuji", note: "Japan's highest peak and an active volcano, considered sacred for centuries." },
      { name: "Fushimi Inari Shrine", note: "Famous for thousands of vermillion torii gates climbing a Kyoto hillside." },
      { name: "Itsukushima Shrine", note: "A shrine whose iconic gate appears to float at high tide." },
    ],
  },

  CHN: {
    history: [
      { year: "221 BCE", label: "Qin Shi Huang unifies China, becomes first emperor" },
      { year: "1279", label: "Yuan dynasty begins — China's first foreign-led dynasty, under the Mongols" },
      { year: "1644", label: "Qing dynasty begins, the last imperial dynasty" },
      { year: "1949", label: "People's Republic of China founded" },
    ],
    culture:
      "Chinese civilization has one of the longest continuous histories on Earth, and its philosophical traditions — Confucianism, Daoism, and later Buddhism — still shape social values today.",
    nature:
      "China's geography ranges from the Himalayas along its southwest border to the Gobi Desert in the north and subtropical forest in the south, supporting enormous biodiversity, including the giant panda's only native habitat.",
    food: [
      { name: "Dumplings (jiaozi)", note: "Often eaten for luck during Lunar New Year celebrations." },
      { name: "Peking duck", note: "Roasted to crisp the skin, a centuries-old imperial dish." },
      { name: "Hot pot", note: "A communal simmering broth where diners cook their own ingredients tableside." },
    ],
    landmarks: [
      { name: "Great Wall of China", note: "Built and rebuilt over centuries by successive dynasties, stretching thousands of kilometers." },
      { name: "Forbidden City", note: "The imperial palace complex in Beijing, home to 24 emperors." },
      { name: "Terracotta Army", note: "Thousands of life-sized clay soldiers buried to guard the first emperor's tomb." },
    ],
  },

  IND: {
    history: [
      { year: "2500 BCE", label: "Indus Valley Civilization flourishes" },
      { year: "268 BCE", label: "Ashoka the Great expands the Mauryan Empire, later embraces Buddhism" },
      { year: "1858", label: "British Crown rule begins after the East India Company era" },
      { year: "1947", label: "India gains independence, partitioned into India and Pakistan" },
    ],
    culture:
      "India is home to the origins of Hinduism, Buddhism, Jainism, and Sikhism, alongside a large Muslim population — few countries hold this density of religious and linguistic diversity. Bollywood produces more films annually than any other national film industry.",
    nature:
      "From the Himalayas in the north to tropical Kerala in the south, India's geography supports an extraordinary range of ecosystems, including the Sundarbans mangrove forest, home to Bengal tigers.",
    food: [
      { name: "Biryani", note: "Layered spiced rice with meat or vegetables, with regional variations across the country." },
      { name: "Dosa", note: "A fermented rice-and-lentil crepe from South India." },
      { name: "Masala chai", note: "Black tea brewed with milk and spices, an everyday ritual." },
    ],
    landmarks: [
      { name: "Taj Mahal", note: "A marble mausoleum built by Emperor Shah Jahan for his wife, completed around 1653." },
      { name: "Varanasi's ghats", note: "Ancient riverside steps along the Ganges, among the oldest continuously inhabited sites in the world." },
      { name: "Hawa Mahal", note: "A honeycombed sandstone palace facade in Jaipur, built to let royal women observe street life unseen." },
    ],
  },

  NPL: {
    history: [
      { year: "1768", label: "Prithvi Narayan Shah unifies Nepal into a single kingdom" },
      { year: "1953", label: "Tenzing Norgay and Edmund Hillary make the first confirmed summit of Everest" },
      { year: "2008", label: "Nepal abolishes its monarchy, becomes a federal republic" },
      { year: "2015", label: "A magnitude 7.8 earthquake devastates the Kathmandu Valley" },
    ],
    culture:
      "Nepal sits at a cultural crossroads between South Asia and Tibet, and Hindu and Buddhist traditions have coexisted here for centuries, often sharing the same temples and festivals.",
    nature:
      "Eight of the world's ten highest peaks lie at least partly within Nepal, including Everest, and the country drops from 8,849m summits to lowland jungle in a remarkably short distance.",
    food: [
      { name: "Momo", note: "Steamed or fried dumplings, Nepal's most iconic street food." },
      { name: "Dal bhat", note: "Lentil soup and rice, the everyday staple eaten across the country." },
      { name: "Sel roti", note: "A ring-shaped rice-flour donut, especially popular during festivals." },
    ],
    landmarks: [
      { name: "Mount Everest", note: "The world's highest peak, straddling the Nepal–Tibet border." },
      { name: "Kathmandu Durbar Square", note: "A cluster of historic palaces and temples at the old royal center." },
      { name: "Phewa Lake, Pokhara", note: "A lake town beneath the Annapurna range, a hub for trekkers." },
    ],
  },

  THA: {
    history: [
      { year: "1238", label: "Sukhothai Kingdom founded, often considered the first Thai state" },
      { year: "1782", label: "Bangkok becomes the capital under the Chakri dynasty" },
      { year: "1932", label: "Constitutional monarchy replaces absolute monarchy" },
      { year: "1997", label: "Asian financial crisis begins in Thailand, spreads across the region" },
    ],
    culture:
      "Thai culture is deeply shaped by Theravada Buddhism, practiced by the vast majority of the population, and by deep respect for the monarchy. The traditional wai greeting reflects a broader cultural emphasis on courtesy and hierarchy.",
    nature:
      "Thailand ranges from dense northern mountain jungle to more than 1,400 islands along its southern coasts, supporting coral reefs, elephants, and some of the region's last wild tigers.",
    food: [
      { name: "Pad thai", note: "Stir-fried rice noodles with egg, tofu or shrimp, and tamarind, popularized nationally in the 1930s–40s." },
      { name: "Tom yum", note: "A hot and sour soup built on lemongrass, galangal, and lime leaf." },
      { name: "Mango sticky rice", note: "Sweet coconut rice paired with ripe mango, a beloved dessert." },
    ],
    landmarks: [
      { name: "Grand Palace", note: "The former royal residence in Bangkok, home to the revered Emerald Buddha." },
      { name: "Ayutthaya", note: "Ruins of a former capital, once one of the world's largest cities before its destruction in 1767." },
      { name: "Phi Phi Islands", note: "Limestone cliffs and turquoise water made famous well beyond Thailand's borders." },
    ],
  },

  AUS: {
    history: [
      { year: "~65,000 BCE", label: "Aboriginal Australians arrive, beginning the world's oldest continuous living culture" },
      { year: "1770", label: "James Cook charts the east coast, claims it for Britain" },
      { year: "1788", label: "First British penal colony established at Sydney Cove" },
      { year: "1901", label: "Australian colonies federate into a single nation" },
    ],
    culture:
      "Aboriginal and Torres Strait Islander cultures represent the longest continuous cultures on Earth, with oral traditions and art stretching back tens of thousands of years. Modern Australian identity blends this deep heritage with a multicultural population shaped by post-war immigration.",
    nature:
      "Isolated for millions of years, Australia evolved a wildly distinct ecosystem — marsupials like kangaroos and koalas, and the Great Barrier Reef, the largest living structure on Earth, visible from space.",
    food: [
      { name: "Meat pie", note: "A handheld savory pie, an everyday lunch staple." },
      { name: "Vegemite on toast", note: "A salty yeast-extract spread that divides outsiders and unites locals." },
      { name: "Barramundi", note: "A prized native fish, common on menus near the coast." },
    ],
    landmarks: [
      { name: "Sydney Opera House", note: "Its sail-like shells took over a decade to build and became a UNESCO World Heritage Site." },
      { name: "Uluru", note: "A massive sandstone monolith sacred to the Anangu people, glowing red at sunset." },
      { name: "Great Barrier Reef", note: "Stretching over 2,300 km, made up of nearly 3,000 individual reefs." },
    ],
  },

  ISL: {
    history: [
      { year: "874", label: "Norse settler Ingólfur Arnarson founds the first permanent settlement" },
      { year: "930", label: "The Althing, one of the world's oldest parliaments, is established" },
      { year: "1944", label: "Iceland becomes a fully independent republic" },
      { year: "2010", label: "Eyjafjallajökull's eruption grounds air travel across much of Europe" },
    ],
    culture:
      "With a population under 400,000, Iceland retains an unusually close relationship to its Norse sagas and folklore — polls have found a majority of residents willing to say they believe elves or hidden folk are at least possible.",
    nature:
      "Sitting on the Mid-Atlantic Ridge, Iceland is one of the most volcanically active places on Earth, with glaciers, geysers, and lava fields often within view of each other.",
    food: [
      { name: "Skyr", note: "A thick, protein-rich dairy product similar to yogurt, eaten for over a thousand years." },
      { name: "Plokkfiskur", note: "A comforting mashed fish and potato dish." },
      { name: "Rúgbrauð", note: "Dense rye bread, traditionally baked using geothermal heat." },
    ],
    landmarks: [
      { name: "Blue Lagoon", note: "A geothermal spa formed from mineral-rich water near a power plant." },
      { name: "Gullfoss", note: "A powerful two-tiered waterfall on the popular 'Golden Circle' route." },
      { name: "Þingvellir", note: "A rift valley where the North American and Eurasian plates are visibly pulling apart — and the site of the original Althing." },
    ],
  },
};
