import React, { useEffect, useState } from "react";
import { Dimensions, Pressable, Text, View } from "react-native";
import { useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import Animated, { FadeOut } from "react-native-reanimated";
import { SafeAreaView } from "react-native-safe-area-context";
import { Globe, type GlobeLayer } from "../components/globe/Globe";
import { CountrySearchSheet } from "../components/search/CountrySearchSheet";
import { GradientBackground } from "../components/ui/Primitives";
import { useTheme } from "../theme/ThemeProvider";
import { useAppStore } from "../store/useAppStore";
import { COUNTRIES } from "../data/countries";

const LAYERS: { key: GlobeLayer; label: string }[] = [
  { key: "political", label: "Political" },
  { key: "density", label: "Population" },
];

export default function HomeScreen() {
  const { colors, type, space } = useTheme();
  const router = useRouter();
  const [searchOpen, setSearchOpen] = useState(false);
  const [showHint, setShowHint] = useState(true);
  const [layer, setLayer] = useState<GlobeLayer>("political");
  const recents = useAppStore((s) => s.recents);

  const { width } = Dimensions.get("window");
  const globeSize = Math.min(width - 32, 420);

  useEffect(() => {
    const t = setTimeout(() => setShowHint(false), 4500);
    return () => clearTimeout(t);
  }, []);

  const goToCountry = (cca3: string) => {
    setSearchOpen(false);
    router.push(`/country/${cca3}`);
  };

  const recentCountries = recents.map((id) => COUNTRIES.find((c) => c.id === id)).filter(Boolean);

  return (
    <GradientBackground>
      <SafeAreaView style={{ flex: 1 }}>
        <View style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: space.lg, paddingTop: space.sm }}>
          <View style={{ flex: 1 }}>
            <Text style={[type.hero, { color: colors.textPrimary, fontSize: 30 }]}>Terra</Text>
            <Text style={[type.subtitle, { color: colors.textMuted }]}>Explore the world, one country at a time</Text>
          </View>
          <Pressable
            onPress={() => setSearchOpen(true)}
            hitSlop={12}
            style={{
              width: 44,
              height: 44,
              borderRadius: 22,
              backgroundColor: colors.surfaceRaised,
              borderWidth: 1,
              borderColor: colors.border,
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Ionicons name="search" size={20} color={colors.accent} />
          </Pressable>
        </View>

        <View style={{ flexDirection: "row", justifyContent: "center", gap: space.sm, marginBottom: space.sm }}>
          {LAYERS.map((l) => {
            const active = layer === l.key;
            return (
              <Pressable
                key={l.key}
                onPress={() => setLayer(l.key)}
                style={{
                  paddingVertical: 6,
                  paddingHorizontal: 14,
                  borderRadius: 999,
                  backgroundColor: active ? colors.accent : "transparent",
                  borderWidth: 1,
                  borderColor: active ? colors.accent : colors.border,
                }}
              >
                <Text style={[type.label, { color: active ? colors.background : colors.textMuted }]}>
                  {l.label.toUpperCase()}
                </Text>
              </Pressable>
            );
          })}
        </View>

        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <Globe size={globeSize} layer={layer} onSelectCountry={goToCountry} />

          {showHint && (
            <Animated.View exiting={FadeOut.duration(400)} style={{ position: "absolute", bottom: -8, alignItems: "center" }}>
              <Text style={[type.bodySmall, { color: colors.textMuted }]}>
                Drag to rotate · Pinch to zoom · Tap a country
              </Text>
            </Animated.View>
          )}
        </View>

        {recentCountries.length > 0 && (
          <View style={{ paddingHorizontal: space.lg, paddingBottom: space.md }}>
            <Text style={[type.section, { color: colors.textMuted, marginBottom: space.sm }]}>RECENTLY EXPLORED</Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: space.sm }}>
              {recentCountries.slice(0, 6).map((c) => (
                <Pressable
                  key={c!.id}
                  onPress={() => goToCountry(c!.id)}
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    backgroundColor: colors.surfaceRaised,
                    borderRadius: 999,
                    paddingVertical: 6,
                    paddingHorizontal: 12,
                    borderWidth: 1,
                    borderColor: colors.border,
                  }}
                >
                  <Text style={{ fontSize: 16, marginRight: 6 }}>{c!.flagEmoji}</Text>
                  <Text style={[type.bodySmall, { color: colors.textPrimary }]}>{c!.name.common}</Text>
                </Pressable>
              ))}
            </View>
          </View>
        )}
      </SafeAreaView>

      <CountrySearchSheet visible={searchOpen} onClose={() => setSearchOpen(false)} onSelect={goToCountry} />
    </GradientBackground>
  );
}
